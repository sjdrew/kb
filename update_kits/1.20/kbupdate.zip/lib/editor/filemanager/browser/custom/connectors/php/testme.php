<?

echo realpath("../../../../../../config.php");

?>