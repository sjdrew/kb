
FCK Editor from http://fckeditor.wikiwikiweb.de/

Changes by Steve Drew for integration...

Sep 2005/

- Removed unused folders such as asp files
- Modified Commans/*.php files to remove /$Type/ from file path, meaning all files store in same root folder.
- copied mpuk file browser to custom fold and modified to support "ServerPath" variable that is passed
  at each invocation to provide a unique path per item (ie KB article)
- Modified common.js to support ServerPath variable
- Modified config.php and filemanager/upload/php/config.php to read from top level config.php which
  contains defines for APP_ROOT_DIR and APP_NAME.  APP_ROOT_DIR is physical path to applications doc root
  and APP_NAME is virtual name, ie "/KB". 
- Added javascript to image diaglog to alert and exit if AllowUploads is not set. Allows server code to setup this
  variable for times that uploads are not permitted.
  
  
  
  