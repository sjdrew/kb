<script language="php">

////////////////////////////////////////////////////////////////////////////////////////////////
// Config and Init 
//
//////
DEFINE("APP_ROOT_DIR",str_replace("\\","/",dirname(__FILE__)) . "/"); 

//
// INSTANCE NAME is now Determined from install/Instance.ini file which is created during install
// and defaults to KB if not found
//
$_Instance = "KB"; // In case .ini file not present
$_fp = @fopen(APP_ROOT_DIR . "install/Instance.ini","r");
if ($_fp) {
	while(!feof($_fp)) {
		$_line = fgets($_fp);
		if (stristr($_line,"Instance=")) { 
			list($_keyword,$_Instance) = explode("=",chop($_line),2);
			break;
		}
	}
	fclose($_fp);
	unset($_line);
	unset($_fp);
}
DEFINE("DBNAME","$_Instance");
DEFINE("APP_NAME",DBNAME); // used by editor for virutal root name
DEFINE("FILES_FOLDER","files/"); 
DEFINE("FILES_VPATH", DBNAME . "/" . FILES_FOLDER);
DEFINE("COMPANY","HP");
DEFINE("SITENAME",COMPANY . DBNAME);
DEFINE("APPID",strtoupper(DBNAME));
DEFINE("SITE_URL","http://" . $_SERVER['SERVER_NAME'] . "/" . DBNAME . "/");
DEFINE("AUTHENTICATE_ID",strtoupper(DBNAME)."-Auth");
DEFINE("DBTYPE","mssql");
DEFINE("DBHOST","localhost");
DEFINE("DBUSER","KBApp");
DEFINE("DBPASS",'kb$zz01');
DEFINE("APP_VERSION", "1.10");
DEFINE("DBVERSION","1.10");
DEFINE("MAILFROM", "From: steve.drew@hp.com\nReply-To: steve.drew@hp.com\n");  
DEFINE("NOTIFY_ON_ERROR","steve.drew@hp.com");
DEFINE("USERS_TABLE","users");
DEFINE("MAXROWS",5000);  // Searches are limited to this: TODO add to settings page
//DEFINE("REMEDY_SERVER","cs1remedy1"); // comment out if no Remedy Integration wanted.

define("AUTHENTICATION_MODE","Local"); // NT or LOCAL
define("ALLOW_GUESTS",1);			// if true then auto create a User account on first access with Guest permissions
									// else provide message that they must have an account. Valid for NT mode only

define("KB_UPDATE_SERVER","softperfection.com");
define("KB_UPDATES_FOLDER","kbupdates");
define("KB_UPDATE_URL","http://" . KB_UPDATE_SERVER . "/" . KB_UPDATES_FOLDER . "/kbupdate.dat?A"); // ptr to script

//
// FORM_STYLE Form Style used for Input pages
//
$FORM_STYLE    = 'style="background-color: #eaeaea" border="0" cellpadding="1" cellspacing="0" ';

//
// $CONTENT_STYLE = Content Style used for list or menu choice windows, defined elsewhere but required. 
//
$CONTENT_STYLE = 'style="background-color: #eaeaea; border-collapse: collapse" BORDER="1" CELLPADDING="4" CELLSPACING="0" ';

// 
// GLOBALS
//
global $printview;
global $AppDB;
global $SimulateID;

if (file_exists("lib/CustomActions.php")) include_once("lib/CustomActions.php");
include_once("lib/subs_library.php");
include_once("lib/subs_db.php");
include_once("lib/subs_cal.php");
include_once("lib/subs_auth.php");
include_once("lib/listbox.php");
include_once("lib/listboxpref.php");
include_once("lib/subs_datetime.php");
include_once("lib/subs_kb.php");
include_once("lib/mail/htmlMimeMail.php");
include_once("lib/template.php");
//nocache();

global $db_err_routine;
$db_err_routine = "db_err";
</script>