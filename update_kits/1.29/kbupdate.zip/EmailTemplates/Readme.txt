Please note:

If you may any changes to templates, remember to save a copy of your custom template otherwise an KB
upgrade may overwrite your changes.
